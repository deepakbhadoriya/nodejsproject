const express = require("express");
const mongoose = require("mongoose");
const bodyparser = require("body-parser");
const passport = require("passport");

//bring all routes
const auth = require("./routes/api/auth");
const profile = require("./routes/api/profile");
const question = require("./routes/api/question");

const app = express();

//Middleware for bodyparser
app.use(bodyparser.urlencoded({extended: false}));
app.use(bodyparser.json());

//mongo DB Configuration
const db = require("./setup/myurl").mongoURL;

//DB connection
mongoose
  .connect(db)
  .then(() => console.log("database connected"))
  .catch(err => console.log(err));

//passport middleware
app.use(passport.initialize());

//Config for JWT strategy
require("./stratagies/jsonwtStrategy")(passport);

//just to test routes
app.get("/", (req, res) => {
  res.send(`Hello world`);
});

//actual routes
app.use("/api/auth", auth);
app.use("/api/profile", profile);
app.use("/api/question", question);

const port = process.env.port || 3000;

app.listen(port, () => console.log(`Server is running at port ${port}`));

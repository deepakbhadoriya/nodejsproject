module.exports = {
  mongoURL:
    "mongodb+srv://deepak1234:deepak1234@cluster0-tsto0.mongodb.net/test?retryWrites=true&w=majority",
  secret: "mystrongsecret"
};
